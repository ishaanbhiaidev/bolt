import { atom } from 'nanostores';

export const streamingState = atom<boolean>(false);
